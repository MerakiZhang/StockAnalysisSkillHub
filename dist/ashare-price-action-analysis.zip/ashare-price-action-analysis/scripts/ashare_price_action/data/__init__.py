"""Stock-market data layer."""
