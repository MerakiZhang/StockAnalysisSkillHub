"""Stock-analysis configuration."""
