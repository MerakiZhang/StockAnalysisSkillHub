"""Simple deterministic market-structure features for LLM grounding.

Computes only objective, low-ambiguity facts (range position, overlap, swings,
breakout reclaim, H/L count triggers, structure/MM candidates). Complex pattern
labels (wedge, MTR, etc.) remain with the model.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from ashare_price_action.data.base import KlineBar, KlineFrame
from ashare_price_action.util.price_tick import infer_price_tick_from_frame

MARKET_FEATURES_SECTION_PREFIX = "## 程序结构辅助特征"
_DEFAULT_LOOKBACK = 40
_RECENT_BREAKOUT_MAX_SEQ = 12
_MAX_BREAKOUT_EVENTS = 6
_EVENT_PRIORITY = {"failed": 0, "breakout": 1, "test": 2}
_OVERLAP_WINDOW = 10
_BARBWIRE_OVERLAP_THRESHOLD = 0.65
_BARBWIRE_WIDTH_ATR_MAX = 3.0
_BARBWIRE_SCORE_THRESHOLD = 0.6
_BREAKOUT_RECLAIM_BARS = 5
_BREAKOUT_TEST_TOLERANCE_ATR = 0.15
_SURVIVING_MIN_BARS = 5
_SPIKE_LOOKBACK = 16
_SPIKE_MIN_RUN = 3
_SCALE_RECENT = 20
_SCALE_BG_START = 40


@dataclass(frozen=True)
class SwingPivot:
    seq: int
    kind: str  # high | low
    price: float


@dataclass(frozen=True)
class BreakoutEvent:
    level_price: float
    level_kind: str
    event: str  # breakout | failed | test
    trigger_seq: int
    bar_range: str
    note: str
    attempt_type: str = "close"  # wick | close


@dataclass(frozen=True)
class HLCountState:
    """H/L trigger count inside the CURRENT pullback leg (not over the whole window).

    bull_count counts H triggers since the most recent confirmed swing high, as long as that
    swing high has not been exceeded; bear_count is the mirror for L triggers after a swing low.
    0 / "none" also means "no active pullback leg".
    """

    bull_count: int
    bear_count: int
    last_bull_trigger_seq: int | None
    last_bear_trigger_seq: int | None
    bull_candidate: str  # none | h1 | h2 | h3
    bear_candidate: str  # none | l1 | l2 | l3
    bar_range: str
    bull_leg_start_seq: int | None = None  # seq of the swing high that started the active leg
    bear_leg_start_seq: int | None = None  # seq of the swing low that started the active leg


@dataclass(frozen=True)
class MeasuredMoveCandidate:
    kind: str  # range_up | range_down | leg_up | leg_down
    reference: str
    height: float
    target_price: float
    bar_range: str


@dataclass(frozen=True)
class SimpleMarketFeatures:
    lookback_bars: int
    range_high: float | None
    range_low: float | None
    range_width_atr: float | None
    price_position: float | None
    zone: str
    dist_to_high_atr: float | None
    dist_to_low_atr: float | None
    overlap_mean_10: float | None
    doji_inside_ratio_10: float | None
    barbwire_score: float
    barbwire_candidate: bool
    swing_structure: str
    swings: tuple[SwingPivot, ...]
    pullback_depth_atr: float | None
    pullback_bars: int | None
    breakout_events: tuple[BreakoutEvent, ...]
    hl_count: HLCountState
    supports: tuple[float, ...]
    resistances: tuple[float, ...]
    invalidation_long: float | None
    invalidation_short: float | None
    measured_moves: tuple[MeasuredMoveCandidate, ...]
    # Empiric-aligned structure quality (program-computed)
    breakout_quality: str  # none|wick_probe|close_breakout|failed|testing|surviving
    breakout_attempt_type: str | None  # wick|close|None
    mm_as_tp_ok: bool  # True only when breakout_quality == surviving
    spike_aftermath_hint: str  # none|continued|pullback|origin_break_risk|sticky_reversal_risk
    scale_conflict: bool  # recent vs background net direction disagree


def compute_simple_market_features(
    frame: KlineFrame,
    *,
    lookback: int = _DEFAULT_LOOKBACK,
) -> SimpleMarketFeatures:
    """Compute the simple pre-calculation bundle for one KlineFrame."""
    bars = frame.bars
    n = len(bars)
    if n == 0:
        return _empty_features(lookback)

    window = bars[: min(lookback, n)]
    atr_val = _current_atr(frame)
    close = float(window[0].close)

    range_high, range_low = _range_envelope(window)
    range_width_atr = None
    price_position = None
    zone = "unknown"
    dist_high = None
    dist_low = None

    if range_high is not None and range_low is not None and range_high > range_low:
        width = range_high - range_low
        if atr_val and atr_val > 0:
            range_width_atr = round(width / atr_val, 3)
            dist_high = round((range_high - close) / atr_val, 3)
            dist_low = round((close - range_low) / atr_val, 3)
        price_position = round((close - range_low) / width, 3)
        zone = _zone_from_position(price_position)

    overlap_mean = _mean_overlap_ratio(window, min(_OVERLAP_WINDOW, len(window)))
    doji_ratio = _doji_inside_ratio(window, min(_OVERLAP_WINDOW, len(window)))
    barbwire_score = _barbwire_score(
        overlap_mean,
        doji_ratio,
        range_width_atr,
        window,
        atr_val,
    )

    swings = _find_swings_with_seq(window)
    swing_structure = _label_swing_structure(swings)
    pullback_depth, pullback_bars = _pullback_metrics(window, swings, atr_val, close)

    tick = infer_price_tick_from_frame(frame) or 0.0
    raw_breakout_events = _detect_breakout_events(
        window,
        range_high,
        range_low,
        tick=tick,
        atr=atr_val,
    )
    breakout_events = _dedupe_breakout_events(raw_breakout_events)

    hl_count = _compute_hl_count(window)
    supports, resistances = _structure_levels(window, close, swings)
    invalidation_long = supports[0] if supports else None
    invalidation_short = resistances[0] if resistances else None
    measured_moves = _measured_move_candidates(
        range_high,
        range_low,
        swings,
        close,
        lookback=min(lookback, n),
    )
    breakout_quality, breakout_attempt_type = _classify_breakout_quality(
        window,
        breakout_events,
        range_high,
        range_low,
        atr_val,
    )
    mm_as_tp_ok = breakout_quality == "surviving"
    # Only keep aggressive range-MM emphasis when surviving; still list candidates for context
    spike_aftermath_hint = _spike_aftermath_hint(window, atr_val)
    scale_conflict = _scale_conflict(window)

    return SimpleMarketFeatures(
        lookback_bars=min(lookback, n),
        range_high=range_high,
        range_low=range_low,
        range_width_atr=range_width_atr,
        price_position=price_position,
        zone=zone,
        dist_to_high_atr=dist_high,
        dist_to_low_atr=dist_low,
        overlap_mean_10=overlap_mean,
        doji_inside_ratio_10=doji_ratio,
        barbwire_score=round(barbwire_score, 3),
        barbwire_candidate=barbwire_score >= _BARBWIRE_SCORE_THRESHOLD,
        swing_structure=swing_structure,
        swings=tuple(swings),
        pullback_depth_atr=pullback_depth,
        pullback_bars=pullback_bars,
        breakout_events=tuple(breakout_events),
        hl_count=hl_count,
        supports=tuple(supports),
        resistances=tuple(resistances),
        invalidation_long=invalidation_long,
        invalidation_short=invalidation_short,
        measured_moves=tuple(measured_moves),
        breakout_quality=breakout_quality,
        breakout_attempt_type=breakout_attempt_type,
        mm_as_tp_ok=mm_as_tp_ok,
        spike_aftermath_hint=spike_aftermath_hint,
        scale_conflict=scale_conflict,
    )


def render_simple_market_features(features: SimpleMarketFeatures) -> str:
    """Render a compact Chinese summary for Stage 1 / Stage 2 prompts."""
    lines = [
        "## 程序结构辅助特征（简单预计算，客观参考；楔形/MTR 等复杂形态仍由你判断）",
        "",
        "### 区间位置",
    ]
    if features.range_high is not None and features.range_low is not None:
        lines.append(
            f"- 近{features.lookback_bars}棒包络：高 **{features.range_high}** / 低 **{features.range_low}**"
        )
        if features.range_width_atr is not None:
            lines.append(f"- 区间宽度：{features.range_width_atr}×ATR")
        if features.price_position is not None:
            zone_zh = {
                "upper_third": "上三分之一（偏阻力/上沿）",
                "middle_third": "中部（区间中部风险高）",
                "lower_third": "下三分之一（偏支撑/下沿）",
                "unknown": "未知",
            }.get(features.zone, features.zone)
            lines.append(
                f"- 收盘位置分位：**{features.price_position:.2f}** → {zone_zh}"
            )
        if features.dist_to_high_atr is not None and features.dist_to_low_atr is not None:
            lines.append(
                f"- 距上沿 {features.dist_to_high_atr}×ATR / 距下沿 {features.dist_to_low_atr}×ATR"
            )
    else:
        lines.append("- 数据不足，未计算区间包络")

    lines.extend(["", "### 重叠 / 铁丝网"])
    if features.overlap_mean_10 is not None:
        lines.append(f"- 近10棒平均重叠：{features.overlap_mean_10:.2f}")
    if features.doji_inside_ratio_10 is not None:
        lines.append(f"- 近10棒十字星+内包占比：{features.doji_inside_ratio_10:.0%}")
    lines.append(
        f"- 铁丝网分数：**{features.barbwire_score:.2f}**"
        f"（{'≥阈值，候选铁丝网/TTR' if features.barbwire_candidate else '未达铁丝网阈值'}）"
    )

    lines.extend(["", "### 波段结构"])
    lines.append(f"- 结构标签：**{features.swing_structure}**")
    if features.swings:
        swing_text = ", ".join(
            f"K{p.seq}{'高' if p.kind == 'high' else '低'}{p.price}" for p in features.swings[:6]
        )
        lines.append(f"- 最近枢轴（新→旧）：{swing_text}")
    if features.pullback_depth_atr is not None:
        bars_part = f"，持续{features.pullback_bars}棒" if features.pullback_bars else ""
        lines.append(f"- 自最近极点回撤：{features.pullback_depth_atr}×ATR{bars_part}")

    lines.extend(["", "### 突破 / 收回 / 回测"])
    quality_zh = {
        "none": "无显著突破",
        "wick_probe": "影线试探（未收盘站稳）",
        "close_breakout": "收盘突破（尚未确认存活）",
        "failed": "突破失败/已收回",
        "testing": "突破回测中",
        "surviving": "存活突破（站稳，MM 可用）",
    }.get(features.breakout_quality, features.breakout_quality)
    lines.append(f"- **突破质量**：**{features.breakout_quality}** → {quality_zh}")
    if features.breakout_attempt_type:
        lines.append(f"- 尝试类型：{features.breakout_attempt_type}")
    lines.append(
        f"- **区间高度 MM 作 TP2**：{'允许（存活突破）' if features.mm_as_tp_ok else '不宜作为主依据（非存活突破）'}"
    )
    if features.breakout_events:
        for ev in features.breakout_events[:4]:
            kind_zh = {
                "range_high": "区间上沿",
                "range_low": "区间下沿",
            }.get(ev.level_kind, ev.level_kind)
            event_zh = {
                "breakout": "突破",
                "failed": "突破失败/收回",
                "test": "突破回测",
            }.get(ev.event, ev.event)
            at = getattr(ev, "attempt_type", "close")
            lines.append(
                f"- {event_zh} {kind_zh} **{ev.level_price}** @ K{ev.trigger_seq}"
                f"（{ev.bar_range}，{at}）{ev.note}"
            )
    else:
        lines.append("- 近窗口内无显著区间突破/收回事件")

    lines.extend(["", "### 尖峰余波 / 多尺度"])
    spike_zh = {
        "none": "近端无典型尖峰余波标签",
        "continued": "尖峰仍在延续",
        "pullback": "尖峰后正常回撤（≠反转）",
        "origin_break_risk": "已威胁/刺破尖峰起点（观察是否粘性）",
        "sticky_reversal_risk": "尖峰起点失守且仍在错边（粘性反转风险）",
    }.get(features.spike_aftermath_hint, features.spike_aftermath_hint)
    lines.append(f"- 尖峰余波提示：**{features.spike_aftermath_hint}** → {spike_zh}")
    lines.append(
        f"- 多尺度方向冲突：**{'是（须压低 diagnosis_confidence，执行跟短窗）' if features.scale_conflict else '否'}**"
    )

    hc = features.hl_count
    lines.extend(["", "### H/L 计数（当前回撤腿内；自最近确认的摆动高/低点起，创出新极值后清零）"])
    if hc.bull_leg_start_seq is None:
        lines.append("- 多头：当前无活跃回撤腿（最近摆动高点已被突破，或窗口内无确认的摆动高点），H1/H2 不适用")
    else:
        cand = hc.bull_candidate.upper() if hc.bull_candidate != "none" else "尚无触发"
        lines.append(
            f"- 多头：自摆动高点 K{hc.bull_leg_start_seq} 起已触发 **{hc.bull_count}** 次 H（候选 {cand}）"
            + (f"，最近触发 K{hc.last_bull_trigger_seq}" if hc.last_bull_trigger_seq else "")
        )
    if hc.bear_leg_start_seq is None:
        lines.append("- 空头：当前无活跃反弹腿（最近摆动低点已被跌破，或窗口内无确认的摆动低点），L1/L2 不适用")
    else:
        cand = hc.bear_candidate.upper() if hc.bear_candidate != "none" else "尚无触发"
        lines.append(
            f"- 空头：自摆动低点 K{hc.bear_leg_start_seq} 起已触发 **{hc.bear_count}** 次 L（候选 {cand}）"
            + (f"，最近触发 K{hc.last_bear_trigger_seq}" if hc.last_bear_trigger_seq else "")
        )
    lines.append(
        "- 口径：H1 = 回撤腿内第一次突破前一棒高点；只有上一次 H 的信号棒低点被跌破（出现新的下探腿）后，"
        "下一次突破才计为 H2，依此类推；L1/L2 对称。"
    )
    lines.append(f"- 计数范围：{hc.bar_range}")

    lines.extend(["", "### 结构价位候选"])
    if features.supports:
        lines.append(f"- 下方支撑（近→远）：{', '.join(str(p) for p in features.supports[:3])}")
    if features.resistances:
        lines.append(f"- 上方阻力（近→远）：{', '.join(str(p) for p in features.resistances[:3])}")
    if features.invalidation_long is not None:
        lines.append(f"- 做多结构失效参考：跌破 **{features.invalidation_long}**")
    if features.invalidation_short is not None:
        lines.append(f"- 做空结构失效参考：升破 **{features.invalidation_short}**")

    lines.extend(["", "### Measured Move 候选（算术投影，非下单依据）"])
    if features.measured_moves:
        for mm in features.measured_moves[:4]:
            lines.append(
                f"- {mm.kind}：高度 {mm.height} → 目标 **{mm.target_price}**"
                f"（{mm.reference}，{mm.bar_range}）"
            )
    else:
        lines.append("- 无足够结构计算 MM")

    lines.append("")
    lines.append(
        "说明：以上为程序客观计算；`detected_patterns` / 三价仍须你结合 playbook 综合判断。"
        "突破质量分层：影线试探失败率高；仅 surviving 时把区间高度 MM 作主要 TP2。"
        "尖峰余波：pullback≠反转；仅 sticky_reversal_risk 才提高反转诊断权重（仍禁止逆势三价）。"
    )
    return "\n".join(lines)


def build_program_features_dict(frame: KlineFrame) -> dict[str, Any]:
    """Compact program-computed facts for stage1_json['program_features']."""
    features = compute_simple_market_features(frame)
    return {
        "barbwire_score": features.barbwire_score,
        "barbwire_candidate": features.barbwire_candidate,
        "overlap_mean_10": features.overlap_mean_10,
        "price_position": features.price_position,
        "zone": features.zone,
        "swing_structure": features.swing_structure,
        "breakout_quality": features.breakout_quality,
        "breakout_attempt_type": features.breakout_attempt_type,
        "mm_as_tp_ok": features.mm_as_tp_ok,
        "spike_aftermath_hint": features.spike_aftermath_hint,
        "scale_conflict": features.scale_conflict,
    }


def inject_market_features_section(prompt: str, features_block: str) -> str:
    """Insert or replace the program market-features block in a Stage 1 user prompt."""
    if not features_block.strip():
        return prompt
    block = features_block.strip()
    if MARKET_FEATURES_SECTION_PREFIX in prompt:
        start = prompt.index(MARKET_FEATURES_SECTION_PREFIX)
        tail = prompt[start:]
        end_rel = len(tail)
        for marker in (
            "\n## 程序预填充",
            "\n请根据以上数据",
            "\n请基于上方完整",
            "\n请基于上一轮结论",
        ):
            if marker in tail:
                end_rel = min(end_rel, tail.index(marker))
        footer = "说明：以上为程序客观计算"
        if footer in tail:
            footer_end = tail.find("\n\n", tail.index(footer))
            if footer_end != -1:
                end_rel = min(end_rel, footer_end)
        return prompt[:start] + block + prompt[start + end_rel :]

    for anchor in (
        "## 程序预填充节点判断依据",
        "请根据以上数据，严格输出阶段一",
        "请基于上方完整K线数据",
        "请基于上一轮结论、新增K线和当前完整K线",
    ):
        if anchor in prompt:
            idx = prompt.index(anchor)
            return prompt[:idx].rstrip() + "\n\n" + block + "\n\n" + prompt[idx:]
    return prompt.rstrip() + "\n\n" + block + "\n"


def _dedupe_breakout_events(events: list[BreakoutEvent]) -> list[BreakoutEvent]:
    """Keep near-term events only; one latest event per price level."""
    if not events:
        return []
    recent = [e for e in events if e.trigger_seq <= _RECENT_BREAKOUT_MAX_SEQ]
    pool = recent if recent else list(events[-_MAX_BREAKOUT_EVENTS:])
    by_level: dict[tuple[str, float], BreakoutEvent] = {}
    for event in pool:
        key = (event.level_kind, round(event.level_price, 6))
        prev = by_level.get(key)
        if prev is None:
            by_level[key] = event
            continue
        if event.trigger_seq < prev.trigger_seq:
            winner = event
        elif event.trigger_seq > prev.trigger_seq:
            winner = prev
        elif _EVENT_PRIORITY[event.event] < _EVENT_PRIORITY[prev.event]:
            winner = event
        else:
            winner = prev
        by_level[key] = winner
    return sorted(by_level.values(), key=lambda e: e.trigger_seq)[:_MAX_BREAKOUT_EVENTS]


def _classify_breakout_quality(
    bars: tuple[KlineBar, ...],
    events: tuple[BreakoutEvent, ...] | list[BreakoutEvent],
    range_high: float | None,
    range_low: float | None,
    atr: float | None,
) -> tuple[str, str | None]:
    """Map recent BO events → quality ladder used for MM gating."""
    if not bars:
        return "none", None

    # Newest-first bars (seq ascending)
    close0 = float(bars[0].close)
    high0 = float(bars[0].high)
    low0 = float(bars[0].low)
    tick_slack = (atr or 0.0) * 0.05

    # Wick probe on newest bar without close beyond envelope
    if range_high is not None and high0 > range_high + tick_slack and close0 <= range_high:
        # If we also have a failed/close event, prefer those below
        wick_only = True
    elif range_low is not None and low0 < range_low - tick_slack and close0 >= range_low:
        wick_only = True
    else:
        wick_only = False

    if not events:
        return ("wick_probe", "wick") if wick_only else ("none", None)

    # Prefer most recent event (smallest seq)
    ordered = sorted(events, key=lambda e: e.trigger_seq)
    latest = ordered[0]
    attempt = getattr(latest, "attempt_type", "close") or "close"

    if latest.event == "failed":
        return "failed", attempt
    if latest.event == "test":
        return "surviving", attempt
    if latest.event == "breakout":
        # Surviving if enough bars since breakout without a later failed on same level
        age = latest.trigger_seq  # seq of breakout bar (1=newest)
        later_fail = any(
            e.event == "failed"
            and e.level_kind == latest.level_kind
            and e.trigger_seq < latest.trigger_seq
            for e in events
        )
        if later_fail:
            return "failed", attempt
        # still outside?
        outside = False
        if latest.level_kind == "range_high" and close0 > latest.level_price:
            outside = True
        if latest.level_kind == "range_low" and close0 < latest.level_price:
            outside = True
        if not outside:
            return "failed", attempt
        if age >= _SURVIVING_MIN_BARS:
            return "surviving", attempt
        return "close_breakout", attempt

    return ("wick_probe", "wick") if wick_only else ("none", None)


def _spike_aftermath_hint(bars: tuple[KlineBar, ...], atr: float | None) -> str:
    """Heuristic spike aftermath label on newest window (not a full Brooks classifier)."""
    n = min(len(bars), _SPIKE_LOOKBACK)
    if n < _SPIKE_MIN_RUN + 2 or not atr or atr <= 0:
        return "none"

    window = bars[:n]
    # Scan for a recent same-direction strong run (chronological oldest→newest within window)
    chrono = list(reversed(window))
    best = None  # (start_i, end_i, direction)
    i = 0
    while i < len(chrono):
        o, h, l, c = float(chrono[i].open), float(chrono[i].high), float(chrono[i].low), float(chrono[i].close)
        body = abs(c - o)
        d = 1 if c > o else (-1 if c < o else 0)
        if d == 0 or body < 0.5 * atr:
            i += 1
            continue
        run = [i]
        j = i + 1
        while j < len(chrono):
            oj, hj, lj, cj = (
                float(chrono[j].open),
                float(chrono[j].high),
                float(chrono[j].low),
                float(chrono[j].close),
            )
            dj = 1 if cj > oj else (-1 if cj < oj else 0)
            if dj != d or abs(cj - oj) < 0.35 * atr:
                break
            run.append(j)
            j += 1
        if len(run) >= _SPIKE_MIN_RUN:
            best = (run[0], run[-1], d)
        i = j if j > i + 1 else i + 1

    if best is None:
        return "none"

    start_i, end_i, d = best
    # origin: low of first bar for up spike, high for down
    if d > 0:
        origin = float(chrono[start_i].low)
        spike_end = float(chrono[end_i].close)
        move = max(spike_end - float(chrono[start_i].open), atr)
    else:
        origin = float(chrono[start_i].high)
        spike_end = float(chrono[end_i].close)
        move = max(float(chrono[start_i].open) - spike_end, atr)

    # bars after spike end
    after = chrono[end_i + 1 :]
    if not after:
        return "continued"

    # continued if more same-dir strong bars immediately
    cont = 0
    for bar in after[:4]:
        o, c = float(bar.open), float(bar.close)
        dj = 1 if c > o else (-1 if c < o else 0)
        if dj == d and abs(c - o) >= 0.45 * atr:
            cont += 1
        else:
            break
    if cont >= 2:
        return "continued"

    last = after[-1]
    last_c = float(last.close)
    if d > 0:
        mae = max(0.0, spike_end - min(float(b.low) for b in after))
        origin_break_close = any(float(b.close) < origin for b in after)
        still_wrong = last_c < origin
    else:
        mae = max(0.0, max(float(b.high) for b in after) - spike_end)
        origin_break_close = any(float(b.close) > origin for b in after)
        still_wrong = last_c > origin

    if origin_break_close and still_wrong and mae >= 0.85 * move:
        return "sticky_reversal_risk"
    if origin_break_close or mae >= 1.0 * move:
        return "origin_break_risk"
    if mae >= 0.25 * move:
        return "pullback"
    return "continued"


def _scale_conflict(bars: tuple[KlineBar, ...]) -> bool:
    """True when recent net direction disagrees with older background net direction."""
    n = len(bars)
    if n < _SCALE_BG_START + 10:
        return False
    recent = bars[:_SCALE_RECENT]
    bg = bars[_SCALE_BG_START : min(n, _SCALE_BG_START + 40)]
    if len(bg) < 10:
        return False
    # bars newest-first: recent[0] newest; net = oldest_close → newest_close in slice
    r_net = float(recent[0].close) - float(recent[-1].close)
    b_net = float(bg[0].close) - float(bg[-1].close)
    if abs(r_net) < 1e-12 or abs(b_net) < 1e-12:
        return False
    return (r_net > 0) != (b_net > 0)


def _empty_features(lookback: int) -> SimpleMarketFeatures:
    empty_hl = HLCountState(0, 0, None, None, "none", "none", "不适用")
    return SimpleMarketFeatures(
        lookback_bars=0,
        range_high=None,
        range_low=None,
        range_width_atr=None,
        price_position=None,
        zone="unknown",
        dist_to_high_atr=None,
        dist_to_low_atr=None,
        overlap_mean_10=None,
        doji_inside_ratio_10=None,
        barbwire_score=0.0,
        barbwire_candidate=False,
        swing_structure="insufficient",
        swings=(),
        pullback_depth_atr=None,
        pullback_bars=None,
        breakout_events=(),
        hl_count=empty_hl,
        supports=(),
        resistances=(),
        invalidation_long=None,
        invalidation_short=None,
        measured_moves=(),
        breakout_quality="none",
        breakout_attempt_type=None,
        mm_as_tp_ok=False,
        spike_aftermath_hint="none",
        scale_conflict=False,
    )


def _current_atr(frame: KlineFrame) -> float | None:
    atr14 = frame.indicators.atr14
    if not atr14:
        return None
    val = atr14[0]
    if math.isnan(val) or val <= 0:
        return None
    return float(val)


def _range_envelope(bars: tuple[KlineBar, ...]) -> tuple[float | None, float | None]:
    if not bars:
        return None, None
    return max(float(b.high) for b in bars), min(float(b.low) for b in bars)


def _zone_from_position(position: float) -> str:
    if position < 1 / 3:
        return "lower_third"
    if position > 2 / 3:
        return "upper_third"
    return "middle_third"


def _overlap_ratio(bar: KlineBar, prev: KlineBar) -> float | None:
    high = min(float(bar.high), float(prev.high))
    low = max(float(bar.low), float(prev.low))
    overlap = max(0.0, high - low)
    denominator = max(float(bar.high), float(prev.high)) - min(float(bar.low), float(prev.low))
    if denominator <= 0:
        return None
    return overlap / denominator


def _mean_overlap_ratio(bars: tuple[KlineBar, ...], window: int) -> float | None:
    if len(bars) < 2 or window < 2:
        return None
    vals: list[float] = []
    limit = min(window, len(bars) - 1)
    for idx in range(limit):
        ratio = _overlap_ratio(bars[idx], bars[idx + 1])
        if ratio is not None:
            vals.append(ratio)
    if not vals:
        return None
    return round(sum(vals) / len(vals), 3)


def _doji_inside_ratio(bars: tuple[KlineBar, ...], window: int) -> float | None:
    if not bars:
        return None
    sample = bars[:window]
    if not sample:
        return None
    count = 0
    for idx, bar in enumerate(sample):
        prev = sample[idx + 1] if idx + 1 < len(sample) else None
        full_range = max(float(bar.high), float(bar.low)) - min(float(bar.high), float(bar.low))
        body = abs(float(bar.close) - float(bar.open))
        is_doji = full_range > 0 and body / full_range <= 0.25
        is_inside = False
        if prev is not None:
            is_inside = float(bar.high) <= float(prev.high) and float(bar.low) >= float(prev.low)
        if is_doji or is_inside:
            count += 1
    return round(count / len(sample), 3)


def _barbwire_score(
    overlap_mean: float | None,
    doji_ratio: float | None,
    range_width_atr: float | None,
    bars: tuple[KlineBar, ...],
    atr: float | None,
) -> float:
    score = 0.0
    if overlap_mean is not None and overlap_mean >= _BARBWIRE_OVERLAP_THRESHOLD:
        score += 0.4
    if doji_ratio is not None and doji_ratio >= 0.4:
        score += 0.2
    if range_width_atr is not None and range_width_atr <= _BARBWIRE_WIDTH_ATR_MAX:
        score += 0.2
    if bars and atr and atr > 0:
        avg_bar = sum(float(b.high) - float(b.low) for b in bars[:_OVERLAP_WINDOW]) / min(
            len(bars), _OVERLAP_WINDOW
        )
        rh, rl = _range_envelope(bars[:_OVERLAP_WINDOW])
        if rh is not None and rl is not None and avg_bar > 0:
            if (rh - rl) / avg_bar < 0.3:
                score += 0.2
    return min(score, 1.0)


def _find_swings_with_seq(bars: tuple[KlineBar, ...]) -> list[SwingPivot]:
    """Local pivots using 1-bar neighbours (aligned with structure_levels)."""
    if len(bars) < 3:
        return []
    pivots: list[SwingPivot] = []
    for i in range(len(bars)):
        h = float(bars[i].high)
        lo = float(bars[i].low)
        is_high = True
        is_low = True
        if i > 0:
            if h <= float(bars[i - 1].high):
                is_high = False
            if lo >= float(bars[i - 1].low):
                is_low = False
        if i + 1 < len(bars):
            if h <= float(bars[i + 1].high):
                is_high = False
            if lo >= float(bars[i + 1].low):
                is_low = False
        if is_high:
            pivots.append(SwingPivot(seq=int(bars[i].seq), kind="high", price=round(h, 6)))
        if is_low:
            pivots.append(SwingPivot(seq=int(bars[i].seq), kind="low", price=round(lo, 6)))
    pivots.sort(key=lambda p: p.seq)
    return pivots


def _label_swing_structure(swings: list[SwingPivot]) -> str:
    highs = sorted([p for p in swings if p.kind == "high"], key=lambda p: p.seq)
    lows = sorted([p for p in swings if p.kind == "low"], key=lambda p: p.seq)
    if len(highs) < 2 or len(lows) < 2:
        return "insufficient"
    # seq ascending: index 0 = newest pivot (K1 side).
    hh = highs[0].price > highs[1].price
    hl = lows[0].price > lows[1].price
    ll = lows[0].price < lows[1].price
    lh = highs[0].price < highs[1].price
    if hh and hl:
        return "HH+HL"
    if ll and lh:
        return "LL+LH"
    return "mixed"


def _pullback_metrics(
    bars: tuple[KlineBar, ...],
    swings: list[SwingPivot],
    atr: float | None,
    close: float,
) -> tuple[float | None, int | None]:
    if not swings or not atr or atr <= 0:
        return None, None
    highs = [p for p in swings if p.kind == "high"]
    lows = [p for p in swings if p.kind == "low"]
    if not highs and not lows:
        return None, None

    # Use the most recent extreme opposite to current close.
    if highs and (not lows or highs[-1].seq >= lows[-1].seq):
        pivot_price = highs[-1].price
        depth = max(0.0, pivot_price - close)
    else:
        pivot_price = lows[-1].price
        depth = max(0.0, close - pivot_price)

    pivot_seq = highs[-1].seq if highs and (not lows or highs[-1].seq >= lows[-1].seq) else lows[-1].seq
    bars_since = max(0, pivot_seq - 1)
    return round(depth / atr, 3), bars_since


def _detect_breakout_events(
    bars: tuple[KlineBar, ...],
    range_high: float | None,
    range_low: float | None,
    *,
    tick: float,
    atr: float | None,
) -> list[BreakoutEvent]:
    if not bars:
        return []

    tolerance = (atr or 0.0) * _BREAKOUT_TEST_TOLERANCE_ATR
    if tick <= 0:
        tick = 0.01
    chronological = list(reversed(bars))
    events: list[BreakoutEvent] = []

    running_high: float | None = None
    running_low: float | None = None
    broke_up_seq: int | None = None
    broke_up_level: float | None = None
    broke_down_seq: int | None = None
    broke_down_level: float | None = None

    for bar in chronological:
        seq = int(bar.seq)
        close = float(bar.close)
        low = float(bar.low)
        high = float(bar.high)

        if running_high is not None and running_low is not None:
            if close > running_high + tick:
                broke_up_seq = seq
                broke_up_level = running_high
                events.append(
                    BreakoutEvent(
                        level_price=running_high,
                        level_kind="range_high",
                        event="breakout",
                        trigger_seq=seq,
                        bar_range=f"K{seq}",
                        note="收盘突破当时区间上沿",
                    )
                )
            elif broke_up_seq is not None and broke_up_level is not None:
                bars_after = broke_up_seq - seq if seq < broke_up_seq else 0
                if close < broke_up_level - tick and bars_after <= _BREAKOUT_RECLAIM_BARS:
                    events.append(
                        BreakoutEvent(
                            level_price=broke_up_level,
                            level_kind="range_high",
                            event="failed",
                            trigger_seq=seq,
                            bar_range=f"K{broke_up_seq}-K{seq}",
                            note="突破后收回区间内",
                        )
                    )
                    broke_up_seq = None
                    broke_up_level = None
                elif (
                    low <= broke_up_level + tolerance
                    and close > broke_up_level
                    and bars_after <= _BREAKOUT_RECLAIM_BARS
                ):
                    events.append(
                        BreakoutEvent(
                            level_price=broke_up_level,
                            level_kind="range_high",
                            event="test",
                            trigger_seq=seq,
                            bar_range=f"K{broke_up_seq}-K{seq}",
                            note="回测上沿后仍收上沿之上",
                        )
                    )

            if running_low is not None and close < running_low - tick:
                broke_down_seq = seq
                broke_down_level = running_low
                events.append(
                    BreakoutEvent(
                        level_price=running_low,
                        level_kind="range_low",
                        event="breakout",
                        trigger_seq=seq,
                        bar_range=f"K{seq}",
                        note="收盘跌破当时区间下沿",
                    )
                )
            elif broke_down_seq is not None and broke_down_level is not None:
                bars_after = broke_down_seq - seq if seq < broke_down_seq else 0
                if close > broke_down_level + tick and bars_after <= _BREAKOUT_RECLAIM_BARS:
                    events.append(
                        BreakoutEvent(
                            level_price=broke_down_level,
                            level_kind="range_low",
                            event="failed",
                            trigger_seq=seq,
                            bar_range=f"K{broke_down_seq}-K{seq}",
                            note="跌破后收回区间内",
                        )
                    )
                    broke_down_seq = None
                    broke_down_level = None
                elif (
                    high >= broke_down_level - tolerance
                    and close < broke_down_level
                    and bars_after <= _BREAKOUT_RECLAIM_BARS
                ):
                    events.append(
                        BreakoutEvent(
                            level_price=broke_down_level,
                            level_kind="range_low",
                            event="test",
                            trigger_seq=seq,
                            bar_range=f"K{broke_down_seq}-K{seq}",
                            note="回测下沿后仍收下沿之下",
                        )
                    )

        running_high = high if running_high is None else max(running_high, high)
        running_low = low if running_low is None else min(running_low, low)

    return events


_HL_PIVOT_RIGHT = 2        # fractal confirmation: 2 bars on each side
_HL_MAX_LEG_BARS = 30      # a pullback leg older than this is no longer treated as "current"


def _count_pullback_triggers(
    highs: list[float],
    lows: list[float],
    seqs: list[int],
) -> tuple[int, int | None, int | None]:
    """Count H triggers in the ACTIVE pullback leg at the end of a chronological window.

    Returns (count, last_trigger_seq, leg_start_seq); leg_start_seq is None when no leg is active.

    Definition (causal, mirrors the validated research version):
      * A leg starts when a fractal swing high (higher than 2 bars on each side) is confirmed.
      * It ends (state cleared) when a later bar's high exceeds that swing high, or after
        ``_HL_MAX_LEG_BARS`` bars.
      * Trigger = a bar after the first pullback bars whose high exceeds the previous bar's high.
      * After a trigger the counter is disarmed; it re-arms only when a later bar trades below the
        previous trigger's signal-bar low (a new down-leg).  The n-th trigger is H_n.
    For L1/L2 call this on mirrored arrays (highs=-lows, lows=-highs).
    """
    n = len(highs)
    state: dict | None = None
    for k in range(n):
        s = k - _HL_PIVOT_RIGHT
        if (
            state is None
            and s >= 2
            and highs[s] > highs[s - 1]
            and highs[s] > highs[s - 2]
            and highs[s] > highs[s + 1]
            and highs[s] > highs[k]
        ):
            state = {"s": s, "sh": highs[s], "count": 0, "armed": True, "sig_low": None, "last": None}
        if state is None:
            continue
        if k > state["s"] + _HL_PIVOT_RIGHT and highs[k] > state["sh"]:
            state = None
            continue
        if k - state["s"] > _HL_MAX_LEG_BARS:
            state = None
            continue
        if not state["armed"] and state["sig_low"] is not None and lows[k] < state["sig_low"]:
            state["armed"] = True
        if state["armed"] and k > state["s"] + _HL_PIVOT_RIGHT and highs[k] > highs[k - 1]:
            state["count"] += 1
            state["last"] = seqs[k]
            state["armed"] = False
            state["sig_low"] = lows[k - 1]
    if state is None:
        return 0, None, None
    return state["count"], state["last"], seqs[state["s"]]


def _compute_hl_count(bars: tuple[KlineBar, ...]) -> HLCountState:
    """H1/H2/L1/L2 count inside the current pullback / rally leg (bars are newest-first)."""
    if len(bars) < 6:
        return HLCountState(0, 0, None, None, "none", "none", "不适用")

    chrono = list(reversed(bars))
    highs = [float(b.high) for b in chrono]
    lows = [float(b.low) for b in chrono]
    seqs = [int(b.seq) for b in chrono]

    bull, last_bull, bull_start = _count_pullback_triggers(highs, lows, seqs)
    bear, last_bear, bear_start = _count_pullback_triggers(
        [-x for x in lows], [-x for x in highs], seqs
    )

    def _tag(count: int, prefix: str) -> str:
        if count <= 0:
            return "none"
        return f"{prefix}{min(count, 3)}"

    newest = int(bars[0].seq)
    oldest = int(bars[-1].seq)
    return HLCountState(
        bull_count=bull,
        bear_count=bear,
        last_bull_trigger_seq=last_bull,
        last_bear_trigger_seq=last_bear,
        bull_candidate=_tag(bull, "h"),
        bear_candidate=_tag(bear, "l"),
        bar_range=f"K{newest}-K{oldest}" if newest != oldest else f"K{newest}",
        bull_leg_start_seq=bull_start,
        bear_leg_start_seq=bear_start,
    )


def _structure_levels(
    bars: tuple[KlineBar, ...],
    close: float,
    swings: list[SwingPivot],
) -> tuple[list[float], list[float]]:
    supports: list[float] = []
    resistances: list[float] = []
    seen: set[float] = set()
    for pivot in reversed(swings):
        key = round(pivot.price, 8)
        if key in seen:
            continue
        seen.add(key)
        if pivot.kind == "low" and pivot.price < close:
            supports.append(pivot.price)
        elif pivot.kind == "high" and pivot.price > close:
            resistances.append(pivot.price)
    supports.sort(reverse=True)
    resistances.sort()
    return supports[:3], resistances[:3]


def _measured_move_candidates(
    range_high: float | None,
    range_low: float | None,
    swings: list[SwingPivot],
    close: float,
    *,
    lookback: int,
) -> list[MeasuredMoveCandidate]:
    out: list[MeasuredMoveCandidate] = []
    if range_high is not None and range_low is not None and range_high > range_low:
        height = round(range_high - range_low, 6)
        out.append(
            MeasuredMoveCandidate(
                kind="range_up",
                reference="区间高度向上翻测",
                height=height,
                target_price=round(range_high + height, 6),
                bar_range=f"K{lookback}-K1",
            )
        )
        out.append(
            MeasuredMoveCandidate(
                kind="range_down",
                reference="区间高度向下翻测",
                height=height,
                target_price=round(range_low - height, 6),
                bar_range=f"K{lookback}-K1",
            )
        )

    highs = sorted([p for p in swings if p.kind == "high"], key=lambda p: p.seq)
    lows = sorted([p for p in swings if p.kind == "low"], key=lambda p: p.seq)
    if len(highs) >= 1 and len(lows) >= 1:
        leg_up = round(highs[0].price - lows[0].price, 6)
        if leg_up > 0:
            out.append(
                MeasuredMoveCandidate(
                    kind="leg_up",
                    reference=f"最近leg K{lows[0].seq}-K{highs[0].seq}",
                    height=leg_up,
                    target_price=round(close + leg_up, 6),
                    bar_range=f"K{highs[0].seq}-K{lows[0].seq}",
                )
            )
        leg_down = round(highs[0].price - lows[0].price, 6)
        if leg_down > 0:
            out.append(
                MeasuredMoveCandidate(
                    kind="leg_down",
                    reference=f"最近leg K{highs[0].seq}-K{lows[0].seq}",
                    height=leg_down,
                    target_price=round(close - leg_down, 6),
                    bar_range=f"K{highs[0].seq}-K{lows[0].seq}",
                )
            )
    return out
